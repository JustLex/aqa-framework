package demo.test;

import webdriver.PropertiesResourceManager;

/**
 * Created by Aleksei on 28.11.2014.
 */
public class Main {
    public static void main(String[] args){
        DemoTest dt = new DemoTest();
        dt.runTest();
    }
}
